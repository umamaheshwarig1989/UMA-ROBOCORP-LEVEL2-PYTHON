from robocorp.tasks import task
from robocorp import browser
from RPA.Browser.Selenium import Selenium
from robocorp import  http, excel
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate
from PIL import Image as PILImage
from PIL import ImageGrab
from fpdf import FPDF
import time
import csv
import os

@task


def robot_spare_bin_python():
    """Insert the sales data for the week and export it as a PDF"""
browser.configure(
slowmo=100,
browser_engine="chromium",
        headless=False,    )

def open_the_intranet_website():
    """Navigates to the given URL"""
    

browser.goto("https://robotsparebinindustries.com/")


def Open_Order_Page():
    """Fills in the login form and clicks the 'Log in' button"""
    page = browser.page()
    page.wait_for_selector("text=Order your robot!") 
    page.click("text=Order your robot!")
    page.click("text=OK")


def download_csv_file():
    """Downloads excel file from the given URL"""
    http.download(url="https://robotsparebinindustries.com/orders.csv", overwrite=True)

def fill_form_with_csv_data():
        """Read data from excel and fill in the sales form"""
        with open('orders.csv', 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                fill_and_submit_order_form(row)  
   
def fill_and_submit_order_form(order):
        """use the CSV data table to submit the Order form"""
        page = browser.page()
        #browser=browser()
        page.wait_for_selector("#head")
        page.select_option("#head", order["Head"]) 
        page.click("#id-body-1")
        page.fill('input[placeholder="Enter the part number for the legs"]', '1')
        page.fill("#address",order["Address"])
        page.click("#order")
    
        while True:
            element = page.query_selector("role=alert")
            text_content = element.inner_text()
            if 'error' in text_content.lower():
                page.wait_for_selector("#order")
                page.click("#order")
            else:
                break
        
        pdf_filename=""
        screenshot_filename=""      
        pdf_filename,screenshot_filename = Generate_pdf_screenshot_filename(order["Order number"],pdf_filename,screenshot_filename)
        screenshot_robot(screenshot_filename)
        create_pdfwithimage(pdf_filename,screenshot_filename)
        #embed_screenshot_to_receipt(screenshot_filename,pdf_filename)
        page.wait_for_selector("#order-another")        
        page.click("#order-another")
        page.click("text=OK")
        
def Generate_pdf_screenshot_filename(OrdrNumber,pdf_filename,screenshot_filename):
    output_directory = "output"
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)        
    pdf_filename = os.path.join(output_directory, "OrderNumber"+OrdrNumber+".pdf")
    screenshot_filename="Screenshot_Ordr"+OrdrNumber+".jpeg"
    return pdf_filename,screenshot_filename        
               
    
def screenshot_robot(screenshot_filename):
    screenshot = ImageGrab.grab()               # Capture the screenshot
    screenshot.save(screenshot_filename)        # Save the screenshot     
    
    
def create_pdfwithimage(pdf_file,screenshot_filename):
    pdf = FPDF()    
    # Add text to the PDF
    text = "Hello, SCreen shot for Order to be saved in this File"
    pdf.add_page()
    pdf.image(screenshot_filename,x=10,y=10,w=100,h=100)   
    # Save the PDF
    pdf.output(pdf_file) 

"""Work flow starts here.. Code to call the functions defined begins here"""          
#open_the_intranet_website()
Open_Order_Page()
#download_csv_file()
fill_form_with_csv_data()



    
    